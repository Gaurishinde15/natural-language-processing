import re
from datetime import datetime

import joblib
import pandas as pd
import streamlit as st
from pathlib import Path
from urllib.parse import urlparse

MODEL_PATH = Path("spam_model.joblib")
DATA_PATH = Path("data/sms_spam_collection.csv")
METRICS_PATH = Path("model_metrics.txt")

st.set_page_config(page_title="SmartSpam AI", page_icon="🛡️", layout="wide")

# Simple, polished styling
st.markdown("""
<style>
.block-container {padding-top: 2rem; max-width: 1150px;}
.hero {padding: 1.4rem 1.6rem; border-radius: 18px; background: linear-gradient(120deg,#14213d,#243b63); color: white; margin-bottom: 1rem;}
.hero h1 {color:white; margin:0; font-size:2.35rem;}
.hero p {color:#e2e8f0; margin:.5rem 0 0 0;}
.small-note {color: #64748b; font-size: .88rem;}
</style>
""", unsafe_allow_html=True)

if "history" not in st.session_state:
    st.session_state.history = []

st.markdown("""
<div class="hero">
  <h1>🛡️ SmartSpam AI</h1>
  <p>NLP-powered SMS spam and suspicious-message risk checker</p>
</div>
""", unsafe_allow_html=True)

if not MODEL_PATH.exists():
    st.error("The trained model has not been created yet.")
    st.markdown("### First, train the model")
    st.code("python -m pip install -r requirements.txt\npython train_model.py\npython -m streamlit run app.py", language="powershell")
    st.info("Training downloads the public UCI SMS Spam Collection dataset. Internet access is required for the first training run.")
    st.stop()

@st.cache_resource
def load_model():
    return joblib.load(MODEL_PATH)

model = load_model()

def inspect_risk(message):
    text = message.lower()
    findings = []

    patterns = [
        (r"\b(otp|one[- ]time password|verification code)\b", "Mentions an OTP or verification code"),
        (r"\b(bank details|account number|card number|cvv|password|pin)\b", "Requests or mentions sensitive account information"),
        (r"\b(prize|winner|won|lottery|claim your reward|free gift)\b", "Prize or reward claim language"),
        (r"\b(urgent|immediately|act now|limited time|expires today|right now)\b", "Creates urgency or time pressure"),
        (r"\b(send money|pay now|transfer money|processing fee|gift card)\b", "Requests money or payment"),
        (r"\b(click here|verify your account|account suspended|account blocked)\b", "Uses a common account-verification or click prompt"),
    ]
    for pattern, description in patterns:
        if re.search(pattern, text):
            findings.append(description)

    urls = re.findall(r"(?:https?://|www\.)[^\s<>]+", message, flags=re.I)
    suspicious_domains = []
    for raw_url in urls:
        candidate = raw_url.rstrip(".,!?;:)")
        parsed = urlparse(candidate if candidate.startswith(("http://", "https://")) else "http://" + candidate)
        host = (parsed.hostname or "").lower()
        if host:
            if host.startswith("xn--") or any(short in host for short in ["bit.ly", "tinyurl.com", "t.co", "is.gd", "cutt.ly"]):
                suspicious_domains.append(host)
    if urls:
        findings.append("Contains a link; inspect the destination before opening")
    if suspicious_domains:
        findings.append("Contains a shortened or encoded-looking domain: " + ", ".join(sorted(set(suspicious_domains))))

    return findings, urls

def classify(message):
    prediction = model.predict([message])[0]
    probabilities = model.predict_proba([message])[0]
    classes = list(model.classes_)
    spam_index = classes.index("spam")
    spam_score = float(probabilities[spam_index])
    findings, urls = inspect_risk(message)
    return prediction, spam_score, findings, urls

tab_check, tab_dashboard, tab_about = st.tabs(["🔎 Check a message", "📊 Dashboard & history", "ℹ️ About"])

with tab_check:
    st.subheader("Analyse an SMS or copied message")
    st.write("Paste a message below. Do not include real passwords, OTPs, or financial details.")
    message = st.text_area(
        "Message text",
        height=150,
        placeholder="Example: Congratulations! You won a prize. Click here to claim it..."
    )
    examples = st.columns(3)
    if examples[0].button("Try spam example", use_container_width=True):
        st.session_state.example_message = "Congratulations! You have won a free prize. Call now to claim your reward."
    if examples[1].button("Try suspicious example", use_container_width=True):
        st.session_state.example_message = "URGENT: Verify your account immediately by clicking this link and entering your password."
    if examples[2].button("Try normal example", use_container_width=True):
        st.session_state.example_message = "Hi, are we still meeting at the library at 4 pm today?"
    if "example_message" in st.session_state:
        message = st.text_area("Example loaded — edit if needed", value=st.session_state.example_message, height=90, key="example_edit")

    if st.button("Analyse Message", type="primary", use_container_width=True):
        if len(message.strip()) < 3:
            st.warning("Please enter a message with a little more detail.")
        else:
            prediction, spam_score, findings, urls = classify(message.strip())
            suspicious = bool(findings)
            likely_spam = prediction == "spam"

            if likely_spam or suspicious:
                st.error("⚠️ Potentially spam or suspicious — be careful")
            else:
                st.success("The model classified this message as likely legitimate. This is not a guarantee of safety.")

            a, b, c = st.columns(3)
            a.metric("Model classification", "Spam" if likely_spam else "Legitimate")
            b.metric("Spam model score", f"{spam_score:.1%}")
            c.metric("Risk indicators", len(findings))

            st.caption("The spam score is the model's estimated class probability, not a guarantee that the message is malicious or safe.")

            st.markdown("#### Why was it flagged?")
            if findings:
                for item in findings:
                    st.write("• " + item)
            else:
                st.write("No indicators from the app's simple rule list were detected.")

            if urls:
                st.warning("Avoid opening unexpected links. This app does not visit or verify URLs.")
                for link in urls:
                    st.code(link)

            st.session_state.history.append({
                "Time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "Message": message.strip(),
                "Classification": "Spam" if likely_spam else "Legitimate",
                "Spam score": round(spam_score, 4),
                "Risk indicators": "; ".join(findings) if findings else "None detected"
            })

with tab_dashboard:
    st.subheader("Analysis dashboard")
    history_df = pd.DataFrame(st.session_state.history)
    if not history_df.empty:
        total = len(history_df)
        spam_count = int((history_df["Classification"] == "Spam").sum())
        legitimate_count = total - spam_count
        x, y, z = st.columns(3)
        x.metric("Messages checked", total)
        y.metric("Classified as spam", spam_count)
        z.metric("Classified as legitimate", legitimate_count)
        st.bar_chart(pd.DataFrame({
            "Messages": [spam_count, legitimate_count]
        }, index=["Spam", "Legitimate"]))
        st.dataframe(history_df, use_container_width=True, hide_index=True)
        st.download_button(
            "⬇️ Download report as CSV",
            data=history_df.to_csv(index=False).encode("utf-8"),
            file_name="smartspam_analysis.csv",
            mime="text/csv"
        )
        if st.button("Clear history"):
            st.session_state.history = []
            st.rerun()
    else:
        st.info("Analyse messages in the first tab to build your session dashboard.")

    if METRICS_PATH.exists():
        with st.expander("View model evaluation from held-out test data"):
            st.text(METRICS_PATH.read_text(encoding="utf-8"))

with tab_about:
    st.subheader("Project overview")
    st.markdown("""
**Objective:** Classify SMS text as spam or legitimate and show additional warning signs that may help users notice suspicious messages.

**NLP and ML techniques**
- TF-IDF text feature extraction with unigram and bigram features
- Multinomial Naive Bayes binary classifier
- Train/test split with stratification
- Precision, recall, F1-score, accuracy and confusion matrix
- Rule-based scam indicators for explainability

**Dataset:** UCI SMS Spam Collection, downloaded by `train_model.py`.

**Limitations:** This is an educational prototype. The dataset mainly contains SMS spam examples, not every modern phishing or scam message. The warning rules are not a verified security system. Do not rely on the app alone to decide whether a message is safe.
""")
    st.caption("SmartSpam AI • NLP Mini Project")
