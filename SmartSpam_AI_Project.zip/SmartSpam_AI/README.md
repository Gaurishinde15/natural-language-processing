# SmartSpam AI — NLP Mini Project

## Features
- SMS spam vs legitimate classification with TF-IDF + Multinomial Naive Bayes
- Extra rule-based warning indicators for OTP/password requests, urgency, prize claims, payment requests, and links
- Streamlit UI with examples, session history, dashboard, and CSV export
- Evaluation metrics on a held-out test set

## Requirements
- Python 3.10 or newer recommended
- Internet connection for the first dataset download

## Run on Windows / VS Code

Open the terminal in this folder and run:

```powershell
python -m pip install -r requirements.txt
python train_model.py
python -m streamlit run app.py
```

The browser usually opens at `http://localhost:8501`.

## Project files
- `train_model.py`: downloads the UCI SMS Spam Collection, trains and evaluates the model
- `app.py`: Streamlit user interface
- `requirements.txt`: dependencies
- `data/sms_spam_collection.csv`: created when training runs
- `spam_model.joblib`: trained model created when training runs
- `model_metrics.txt`: evaluation results created when training runs

## Important notes
- Do not use real private messages containing passwords, OTPs, bank details, or other sensitive information.
- A model prediction is not a guarantee of safety. Verify unexpected messages through official channels.
- The URL rules only flag some patterns; the app does not visit URLs or verify websites.
- This educational model is trained on SMS examples and may not generalize to all email, WhatsApp, or modern scam messages.
