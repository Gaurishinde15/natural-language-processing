"""Download the public UCI SMS Spam Collection dataset and train a baseline model."""
import io
import zipfile
from pathlib import Path

import joblib
import pandas as pd
import requests
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, classification_report, confusion_matrix

DATA_DIR = Path("data")
DATA_DIR.mkdir(exist_ok=True)
MODEL_PATH = Path("spam_model.joblib")
METRICS_PATH = Path("model_metrics.txt")
DATASET_URL = "https://archive.ics.uci.edu/static/public/228/sms+spam+collection.zip"

def main():
    print("Downloading the UCI SMS Spam Collection dataset...")
    response = requests.get(DATASET_URL, timeout=45)
    response.raise_for_status()

    with zipfile.ZipFile(io.BytesIO(response.content)) as archive:
        member = next((n for n in archive.namelist() if n.endswith("SMSSpamCollection")), None)
        if not member:
            raise RuntimeError("Dataset file was not found inside the downloaded archive.")
        raw = archive.read(member).decode("utf-8", errors="replace")

    rows = []
    for line in raw.splitlines():
        parts = line.split("\t", 1)
        if len(parts) == 2 and parts[0].strip().lower() in {"ham", "spam"}:
            rows.append((parts[0].strip().lower(), parts[1].strip()))

    df = pd.DataFrame(rows, columns=["label", "message"]).drop_duplicates()
    df = df[df["message"].str.len() > 0]
    df.to_csv(DATA_DIR / "sms_spam_collection.csv", index=False)

    X_train, X_test, y_train, y_test = train_test_split(
        df["message"], df["label"], test_size=0.2, random_state=42, stratify=df["label"]
    )

    model = Pipeline([
        ("tfidf", TfidfVectorizer(lowercase=True, strip_accents="unicode",
                                  ngram_range=(1, 2), min_df=2, sublinear_tf=True)),
        ("classifier", MultinomialNB(alpha=0.5))
    ])
    model.fit(X_train, y_train)
    predictions = model.predict(X_test)

    metrics = {
        "Dataset rows": len(df),
        "Training messages": len(X_train),
        "Test messages": len(X_test),
        "Accuracy": accuracy_score(y_test, predictions),
        "Spam precision": precision_score(y_test, predictions, pos_label="spam", zero_division=0),
        "Spam recall": recall_score(y_test, predictions, pos_label="spam", zero_division=0),
        "Spam F1-score": f1_score(y_test, predictions, pos_label="spam", zero_division=0),
    }
    joblib.dump(model, MODEL_PATH)

    report = "\n".join(f"{k}: {v:.4f}" if isinstance(v, float) else f"{k}: {v}" for k, v in metrics.items())
    report += "\n\nClassification report:\n" + classification_report(y_test, predictions, zero_division=0)
    report += "\nConfusion matrix (labels: ham, spam):\n" + str(confusion_matrix(y_test, predictions, labels=["ham", "spam"]))
    METRICS_PATH.write_text(report, encoding="utf-8")

    print("\nTraining complete!")
    print(report)
    print(f"\nSaved model to: {MODEL_PATH.resolve()}")
    print(f"Saved dataset to: {(DATA_DIR / 'sms_spam_collection.csv').resolve()}")
    print(f"Saved metrics to: {METRICS_PATH.resolve()}")

if __name__ == "__main__":
    main()
